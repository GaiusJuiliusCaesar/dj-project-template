# Ansible global settings

This project is used to maintain dynamic inventory and global **Ansible** configuration.
