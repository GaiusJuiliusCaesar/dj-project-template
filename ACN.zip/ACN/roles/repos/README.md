REPOS
=========

This role is used to manage the YUM and DNF Repositories.

Example Playbook
----------------

Add this role in the playbook as following.

    - name: Setup Play
      hosts: servers
      become: true
      roles:
        - role: repos

License
-------

BSD

Author Information
------------------

**LR Platform Team**, [BAE Systems Digital Intelligence](https://baesystems.com/di/)
