Amazon CloudWatch Agent
=========

This role is used to manage the Amazon CloudWatch Agent settings.

Role Variables
--------------
```
cw_default_template
cw_log_group_name
cw_app_name
```

Example Playbook
----------------


    - name: Setup Play.
      hosts: servers
      vars:
        cw_default_template: "cd_app_config.json.j2"
        cw_log_group_name: "GAMMA-CD-APP"
        cw_app_name: "cd_app"
      become: true
      roles:
         - role: cloudwatch_agent

License
-------

BSD

Author Information
------------------

**LR Platform Team**, [BAE Systems Digital Intelligence](https://baesystems.com/di/)
