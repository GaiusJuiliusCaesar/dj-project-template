Ad_Join
=========

This role is used to join the Linux to AD.

Example Playbook
----------------

Add this role in the playbook as following.

    - name: Setup Play
      hosts: servers
      vars_files:
        - "{{ ansible_vault_file_path }}ED/imp_net.vault"
      roles:
        - role: ad_join

License
-------

BSD

Author Information
------------------

**Engineering Support**, [BAE Systems Applied
Intelligence](https://baesystems.com/ai/)
