SUDO
=========

This role is used to manage the SUDO Access.

Example Playbook
----------------

Add this role in the playbook as following.

    - name: Setup Play
      hosts: servers
      become: true
      roles:
        - role: sudo

License
-------

BSD

Author Information
------------------

**LR Platform Team**, [BAE Systems Digital Intelligence](https://baesystems.com/di/)
