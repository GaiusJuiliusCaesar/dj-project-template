BASE
=========

This role is used to manage the base settings like /etc/hosts entry,
/etc/resolv.conf settings and Chronyd (NTP) settings.

Example Playbook
----------------

Add this role in the playbook as following.

    - name: Setup Play
      hosts: servers
      become: true
      roles:
        - role: base

License
-------

BSD

Author Information
------------------

**LR Platform Team**, [BAE Systems Digital Intelligence](https://baesystems.com/di/)
