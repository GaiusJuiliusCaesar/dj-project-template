#!/usr/bin/env bash
# -*- coding: utf-8 -*-

##
# Managed by: LR Ansible Control Node.
##

##############################################################################
#
# Name        : housekeeping-codedeploy.sh
# Description : House Keeping for Code Deployments.
#
##############################################################################

#
# Declare Variables.
#
CODE_DROOT="/opt/codedeploy-agent/deployment-root"
EXIT_SUCCESS_CODE=0
EXIT_ERROR_CODE=1
#
# Clean files.
#
if [[ -d "$CODE_DROOT" ]]; then
  find "$CODE_DROOT" -type f -exec rm -f {} \;
  find "$CODE_DROOT" -type d -exec rm -rf {} \;
  exit $EXIT_SUCCESS_CODE
else
  echo "Code Deployment is not installed."
  exit $EXIT_ERROR_CODE
fi
