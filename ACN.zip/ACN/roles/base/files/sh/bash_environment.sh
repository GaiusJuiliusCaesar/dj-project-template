#!/usr/bin/env bash
# -*- coding: utf-8 -*-

##
# Managed by: LR Ansible Control Node.
##

##############################################################################
#
# Name        : bash_environment.sh
# Description : Set BASH SHELL environment.
#
##############################################################################

#
# Declare Variables.
#
PATH=$HOME/.local/bin:$HOME/bin:/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
export PATH
RESET="\[\e[00m\]"
RED="\[\e[41m\]"
LIGHT_GREEN="\[\e[42m\]"
LIGHT_BLUE="\[\e[44m\]"
LIGHT_PURPLE="\[\e[45m\]"
YELLOW="\[\e[33m\]"
GREY="\[\e[40m\]"
#
# Define functions
#
git_branch() {
  git branch 2> /dev/null | sed -e '/^[^*]/d' -e 's/* \(.*\)/(\1)/'
}

#
# Set BASH Shell Environment.
#
if [[ "${AWS_ENV}" == "Production" ]]; then
  export PS1="[${RED}${LR_STACK}${RESET} \u@\h \W]\\$ "
elif [[ "${AWS_ENV}" == "Reference" ]]; then
  export PS1="[${LIGHT_GREEN}${LR_STACK}${RESET} \u@\h \W]\\$ "
elif [[ "${AWS_ENV}" == "DisasterRecovery" ]]; then
  export PS1="[${LIGHT_BLUE}${LR_STACK}${RESET} \u@\h \W]\\$ "
elif [[ "${AWS_ENV}" == "Development" ]]; then
  export PS1="[${LIGHT_PURPLE}${LR_STACK}${RESET} \u@\h \W]\\$ "
elif [[ -z "${AWS_ENV}" ]]; then
  export PS1="[${GREY}NO-STACK${RESET} \u@\h \W]\\$ "
fi
#
# Set BASH Shell Environment for Git.
#

#
# Check if git is installed.
#
rpm -q git >/dev/null 2>&1
#
# Check Status.
#
GIT_RC="$?"
#
# Set BASH Shell Environment for Git.
#
if [[ "${GIT_RC}" -eq 0 ]]; then
  if [[ "${AWS_ENV}" == "Production" ]]; then
    export PS1="[${RED}${LR_STACK}${RESET} \u@\h \W${YELLOW} \$(git_branch)${RESET}]\\$ "
  elif [[ "${AWS_ENV}" == "Reference" ]]; then
    export PS1="[${LIGHT_GREEN}${LR_STACK}${RESET} \u@\h \W${YELLOW} \$(git_branch)${RESET}]\\$ "
  elif [[ "${AWS_ENV}" == "DisasterRecovery" ]]; then
    export PS1="[${LIGHT_BLUE}${LR_STACK}${RESET} \u@\h \W${YELLOW} \$(git_branch)${RESET}]\\$ "
  elif [[ "${AWS_ENV}" == "Development" ]]; then
    export PS1="[${LIGHT_PURPLE}${LR_STACK}${RESET} \u@\h \W${YELLOW} \$(git_branch)${RESET}]\\$ "
  elif [[ -z "${AWS_ENV}" ]]; then
    export PS1="[${GREY}NO-STACK${RESET} \u@\h \W${YELLOW} \$(git_branch)${RESET}]\\$ "
  fi
fi

#
# AWS Auto complete
#
complete -C '/usr/local/bin/aws_completer' aws
