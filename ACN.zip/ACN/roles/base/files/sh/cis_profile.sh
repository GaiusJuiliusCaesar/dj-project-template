#!/usr/bin/env bash
# -*- coding: utf-8 -*-

##
# Managed by: LR Ansible Control Node.
##

##############################################################################
#
# Name        : cis_profile.sh
# Description : Load CIS recommended environment variables to login profile.
#
##############################################################################

#
# Define environment Variables.
#
readonly TMOUT=900
export TMOUT
umask 022
