#!/usr/bin/env pwsh
# -*- coding: utf-8 -*-

##
# Managed by: LR Ansible Control Node.
##

##############################################################################
#
# Name        : lrp_aws_ec2_linux_inventory.ps1
# Description : Generate EC2 Linux Platform instances inventory
# Engineer    : Seshadri Raja
# Document    : https://engineering/confluence/x/GdPRKQ
#
##############################################################################

#
# Declare Variables
#

#
# Set the AWS region you want to query
#
$OutFile = "/tmp/LRP_EC2_Linux_inventory_hosts"
$Regions = @(
  "eu-west-1",
  "eu-west-2"
)
$Environs = @(
  "MGMT",
  "PROD",
  "PREPROD"
)
$EnvironsRegEx = @(
  "_MGMT_*",
  "_PROD_*",
  "_PREPROD_*"
)
$EnvironsCount = 0
$TagNameValues = [System.Collections.ArrayList]@()
$TagCount = 0
$EC2Hostname = [System.Collections.ArrayList]@()
$CIDR = [System.Collections.ArrayList]@()
$CIDRCount = 0
#
# Import the AWS.Tools.EC2 module
#
Import-Module -Name AWS.Tools.EC2
#
# Initialize the inventory file.
#
Write-Output "#`n# Inventory file of Protected EC2 Instances.`n#`n" | `
  Out-File -FilePath $OutFile
#
# Retrieve information about all EC2 instances in the specified region
#
ForEach ($Region in $Regions) {
  $Instances = Get-EC2Instance -Filter `
    @{ Name = "instance-state-name"; Values = "running" } -Region $Region
  #
  # Loop through each instance and output its hostname and IP address
  #
  Write-Output $Region.ToUpper().Replace("-", "_").Insert(0, `
    '[').Insert(($Region.Length + 1), '_PROTECTED]') | `
    Out-File -Append -FilePath $OutFile
  ForEach ($Instance in $Instances.Instances) {
    $PrivateDnsName = $Instance.PrivateDnsName
    $PrivateIpAddress = $Instance.PrivateIpAddress
    Write-Output "$PrivateDnsName ansible_host=$PrivateIpAddress ansible_user=centos" | `
      Out-File -Append -FilePath $OutFile
  }
  Write-Output "`n" | Out-File -Append -FilePath $OutFile
}
#
# Generate the EC2 Group Name.
#
ForEach ($Region in $Regions) {
  $Instances = Get-EC2Instance -Filter `
  @{ Name = "instance-state-name"; Values = "running" } -Region $Region
  ForEach ($Instance in $Instances.Instances) {
    $TagName = ($Instance.Tags | Where-Object { $_.Key -eq "Name" }).Value
    $TagName = $TagName.Trim().Replace("-", "_").Replace("/", "_").Replace(" ", "_").Replace(".", "_").ToUpper()
    if ($TagNameValues -notcontains $TagName) {
      $TagNameValues.Add($TagName) | Out-Null
    }
  }
}
$TagNameValues = $TagNameValues | Sort-Object -Unique
#
# Match the instance tag key "Name" value mataches the List index.
#
do {
  Write-Output $TagNameValues[$TagCount].Insert(0, `
    '[').Insert(($TagNameValues[$TagCount].Length + 1), ']') |
    Out-File -Append -FilePath $OutFile
  ForEach ($Region in $Regions) {
    $Instances = Get-EC2Instance -Filter `
      @{ Name = "instance-state-name"; Values = "running" } -Region $Region
    #
    # Group the EC2 Instances.
    #
    ForEach ($Instance in $Instances.Instances) {
      $TagName = ($Instance.Tags | Where-Object { $_.Key -eq "Name" }).Value
      $TagName = $TagName.Trim().Replace("-", "_").Replace("/", "_").Replace(" ", "_").Replace(".", "_").ToUpper()
      if ( $TagName -eq $TagNameValues[$TagCount] ) {
        Write-Output $Instance.PrivateDnsName | Out-File -Append -FilePath $OutFile
      }
    }
  }
  $TagCount += 1
  Write-Output "`n" | Out-File -Append -FilePath $OutFile
} While ($TagCount -lt $TagNameValues.Count)
#
# Generate CIDR group.
#
ForEach ($Region in $Regions) {
  $Instances = Get-EC2Instance -Filter `
  @{ Name = "instance-state-name"; Values = "running" } -Region $Region
  ForEach ($Instance in $Instances.Instances) {
    $EC2Hostname = $Instance.PrivateDnsName.Split('.')[0]
    $EC2Hostname = $EC2Hostname.Split('-')
    $EC2Hostname = $EC2Hostname[0..3] -Join "_"
    if ($CIDR -notcontains $EC2Hostname) {
      $EC2Hostname = $EC2Hostname.ToUpper()
      $CIDR.Add($EC2Hostname) | Out-Null
    }
  }
}
$CIDR = $CIDR | Sort-Object -Unique
#
# Match the instance hostname value mataches the List index.
#
do {
  Write-Output $CIDR[$CIDRCount].Insert(0, `
    '[').Insert(($CIDR[$CIDRCount].Length + 1), ']') |
    Out-File -Append -FilePath $OutFile
  ForEach ($Region in $Regions) {
    $Instances = Get-EC2Instance -Filter `
      @{ Name = "instance-state-name"; Values = "running" } -Region $Region
    #
    # Group the EC2 Instances according to the Assigned CIDR.
    #
    ForEach ($Instance in $Instances.Instances) {
      $EC2IName = $Instance.PrivateDnsName.Split('.')[0]
      $EC2IName = $EC2IName.Split('-')
      $EC2IName = $EC2IName[0..3] -Join "_"
      $EC2IName = $EC2IName.Trim().ToUpper()
      $EC2IName = $EC2IName + '*'
      if ( $CIDR[$CIDRCount] -Like $EC2IName) {
        Write-Output $Instance.PrivateDnsName | Out-File -Append -FilePath $OutFile
      }
    }
  }
  $CIDRCount += 1
  Write-Output "`n" | Out-File -Append -FilePath $OutFile
} While ($CIDRCount -lt $CIDR.Count)
#
# Match the group names and assign according to the environment.
#
do {
  Write-Output $Environs[$EnvironsCount].Insert(0, `
    '[').Insert(($Environs[$EnvironsCount].Length + 1), ':children]') | `
    Out-File -Append $OutFile
    ForEach ($TagNameValue in $TagNameValues) {
      if ($TagNameValue -match $EnvironsRegEx[$EnvironsCount]) {
        Write-Output $TagNameValue | Out-File -Append $OutFile
      }
    }
    $EnvironsCount += 1
    Write-Output "`n" | Out-File -Append -FilePath $OutFile
} While ($EnvironsCount -lt $Environs.Count)
