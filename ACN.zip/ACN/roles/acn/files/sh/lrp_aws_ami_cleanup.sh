#!/usr/bin/env bash
# -*- coding: utf-8 -*-

##
# Managed by: LR Ansible Control Node.
##

##############################################################################
#
# Name        : aws_ami_cleanup.sh
# Description : Cleanup old AMI images which are not in use.
# Engineer    : Seshadri Raja
#
##############################################################################

#
# Set exit status
#
EXIT=0
#
# Define functions
#
dateinfo() {
  echo "$(date +'%F %T.%N') INFO:"
}

dateerror() {
  echo "$(date +'%F %T.%N') ERROR:"
}
#
# Define Variables.
#
AMI_OUTPUT="/tmp/aws_old_ami.txt"
AMI_LOCK_FILE="/tmp/aws_old_ami.lock"
LOG_FILE="/var/log/ansible/aws_ami_cleanup.log"
REGIONS=(
  "eu-west-1"
  "eu-west-2"
)
#
# Track time required to run script.
#
START=$(date +%s)
echo "$(dateinfo) Starting.." >>"${LOG_FILE}"
#
# Check for existing process.
#
echo "$(dateinfo) Checking for existing process." >>"${LOG_FILE}"
if [[ -f "${AMI_LOCK_FILE}" ]]; then
  EXIT=1
  echo "$(dateerror) Script $0 is already running or in hung state ${AMI_LOCK_FILE}" >>"${LOG_FILE}"
  END="$(date +%s)"
  echo "$(dateinfo) exiting with code ${EXIT} after $((END - START)) seconds." >>"${LOG_FILE}"
  exit "${EXIT}"
fi
#
# Collect AMI Images which are not in use.
#
touch "${AMI_LOCK_FILE}" >/dev/null 2>&1
for REGION in "${REGIONS[@]}"
do
  echo "$(dateinfo) Running in region ${REGION}" >>"${LOG_FILE}"
  echo "$(dateinfo) Collecting Old AMI Images." >>"${LOG_FILE}"
  # shellcheck disable=SC2016
  aws ec2 describe-images \
    --owners self \
    --region "${REGION}" \
    --query 'Images[?
    !contains(ImageId, `ami-0ce3297dc1eef1505`) &&
    !contains(ImageId, `ami-0807f411dd8fb7f62`) &&
    !contains(ImageId, `ami-0b4370bce2fe36171`) &&
    !contains(ImageId, `ami-092ce65f0e6200940`) &&
    !contains(ImageId, `ami-0a9c6fa659c47331e`) &&
    !contains(ImageId, `ami-03fa8279f0c9a31aa`) &&
    !contains(ImageId, `ami-0b78f49aea2544ae6`) &&
    !contains(ImageId, `ami-0385cd7af67a54e75`) &&
    !contains(ImageId, `ami-0bdca496f496a10ee`) &&
    !contains(ImageId, `ami-02e529bc38f1ce983`) &&
    !contains(ImageId, `ami-07c544a276a5f5f68`) &&
    !contains(ImageId, `ami-0ba0dd1f4696d52be`) &&
    !contains(ImageId, `ami-0faebc9bcf44f7d4f`) &&
    !contains(ImageId, `ami-014fdb473f82d882c`) &&
    !contains(ImageId, `ami-014bcbf83eb2149f4`) &&
    !contains(ImageId, `ami-0fbdc21ec35e2a17e`) &&
    !contains(ImageId, `ami-0007c95d51c2c41b1`) &&
    !contains(ImageId, `ami-04ac5f46471d15867`) &&
    !contains(ImageId, `ami-08e2847882d8368b7`) &&
    !contains(ImageId, `ami-0d45fd5a66af32726`) &&
    !contains(ImageId, `ami-0cf92695f4e3b95b8`) &&
    !contains(ImageId, `ami-04814b840873c675d`) &&
    !contains(ImageId, `ami-032a9bfc80c096944`) &&
    !contains(ImageId, `ami-006ae5eb6e86d9347`) &&
    !contains(ImageId, `ami-0905f91e03f2d5041`) &&
    !contains(ImageId, `ami-081bdb7e0e7375dd1`) &&
    !contains(ImageId, `ami-055014b81c2e4fd22`) &&
    !contains(ImageId, `ami-078b074ddaa883ab9`) &&
    !contains(ImageId, `ami-043852431b8b3fb01`) &&
    !contains(ImageId, `ami-048ab0b3f9c098142`) &&
    !contains(ImageId, `ami-07908b998b79b318e`) &&
    !contains(ImageId, `ami-09322f1eab87d2189`)
    ].[ImageId]' --output text | \
  sort | uniq > "${AMI_OUTPUT}"
  TOTAL_AMI="$(wc -l ${AMI_OUTPUT} | cut -d' ' -f1)"
  echo "$(dateinfo) Total number of AMI in the region ${REGION}: ${TOTAL_AMI}" >>"${LOG_FILE}"
  #
  # Removing the old AMI Images from the AMI_OUTPUT.
  #
  while IFS= read -r AMI_IMAGE
  do
    echo "$(dateinfo) Deregistering AMI Image: ${AMI_IMAGE}" >>"${LOG_FILE}"
    aws ec2 deregister-image \
       --region "${REGION}" \
       --image-id "${AMI_IMAGE}" >>"${LOG_FILE}"
    ACLI_RC="$?"
    if [[ "$ACLI_RC" -eq 0 ]]; then
      echo "$(dateinfo) Successfully deregistered the AMI Image: ${AMI_IMAGE}" >>"${LOG_FILE}"
    else
      echo "$(dateerror) Unable to deregister the AMI Image: ${AMI_IMAGE}" >>"${LOG_FILE}"
    fi
  done < "${AMI_OUTPUT}"
done
#
# Removing the file and exit.
#
shred -uz "${AMI_OUTPUT}" "${AMI_LOCK_FILE}" >/dev/null 2>&1
exit "${EXIT}"
