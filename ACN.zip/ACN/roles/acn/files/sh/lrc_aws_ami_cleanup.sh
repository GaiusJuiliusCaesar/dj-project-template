#!/usr/bin/env bash
# -*- coding: utf-8 -*-

##
# Managed by: LR Ansible Control Node.
##

##############################################################################
#
# Name        : aws_ami_cleanup.sh
# Description : Cleanup old AMI images which are not in use.
# Engineer    : Seshadri Raja
#
##############################################################################

#
# Set exit status
#
EXIT=0
#
# Define functions
#
dateinfo() {
  echo "$(date +'%F %T.%N') INFO:"
}

dateerror() {
  echo "$(date +'%F %T.%N') ERROR:"
}
#
# Define Variables.
#
AMI_OUTPUT="/tmp/aws_old_ami.txt"
AMI_LOCK_FILE="/tmp/aws_old_ami.lock"
LOG_FILE="/var/log/ansible/aws_ami_cleanup.log"
REGIONS=(
  "eu-west-1"
  "eu-west-2"
)
#
# Track time required to run script.
#
START=$(date +%s)
echo "$(dateinfo) Starting.." >>"${LOG_FILE}"
#
# Check for existing process.
#
echo "$(dateinfo) Checking for existing process." >>"${LOG_FILE}"
if [[ -f "${AMI_LOCK_FILE}" ]]; then
  EXIT=1
  echo "$(dateerror) Script $0 is already running or in hung state ${AMI_LOCK_FILE}" >>"${LOG_FILE}"
  END="$(date +%s)"
  echo "$(dateinfo) exiting with code ${EXIT} after $((END - START)) seconds." >>"${LOG_FILE}"
  exit "${EXIT}"
fi
#
# Collect AMI Images which are not in use.
#
touch "${AMI_LOCK_FILE}" >/dev/null 2>&1
for REGION in "${REGIONS[@]}"
do
  echo "$(dateinfo) Running in region ${REGION}" >>"${LOG_FILE}"
  echo "$(dateinfo) Collecting Old AMI Images." >>"${LOG_FILE}"
  # shellcheck disable=SC2016
  aws ec2 describe-images \
    --owners self \
    --region "${REGION}" \
    --query 'Images[?
    !contains(ImageId, `ami-00380dfa875eaf012`) &&
    !contains(ImageId, `ami-009170a392b1593e7`) &&
    !contains(ImageId, `ami-031a03cb800ecb0d5`) &&
    !contains(ImageId, `ami-06004f6d5db80b76a`) &&
    !contains(ImageId, `ami-06db7c2091a01dd0c`) &&
    !contains(ImageId, `ami-07a41a3bf8abd1cdc`) &&
    !contains(ImageId, `ami-07dada231e617e70e`) &&
    !contains(ImageId, `ami-099e9a89dd37cb40b`) &&
    !contains(ImageId, `ami-09a3dd926465adead`) &&
    !contains(ImageId, `ami-0af4bdb9627e51b70`) &&
    !contains(ImageId, `ami-0bcdaf1afd6bfcc59`) &&
    !contains(ImageId, `ami-0c72335d4cee2c454`) &&
    !contains(ImageId, `ami-0d26a663cd30d5658`) &&
    !contains(ImageId, `ami-0d8331a7c0c1ca7fa`) &&
    !contains(ImageId, `ami-0ea4b5ce454fa728e`) &&
    !contains(ImageId, `ami-0f1d8e009aa618f71`) &&
    !contains(ImageId, `ami-0fca75afdd4b43b58`) &&
    !contains(ImageId, `ami-12f9a76b`) &&
    !contains(ImageId, `ami-1986897f`) &&
    !contains(ImageId, `ami-462bbb3f`) &&
    !contains(ImageId, `ami-70edb016`) &&
    !contains(ImageId, `ami-85458dfc`) &&
    !contains(ImageId, `ami-975bbdee`) &&
    !contains(ImageId, `ami-c6972fb5`) &&
    !contains(ImageId, `ami-01b346e8b72cd6307`) &&
    !contains(ImageId, `ami-0fb76dae69bca1674`) &&
    !contains(ImageId, `ami-0ee0a6cf850fe13a2`) &&
    !contains(ImageId, `ami-0d09ad07d9b36cee9`) &&
    !contains(ImageId, `ami-04cbfdd50b9fa5e00`) &&
    !contains(ImageId, `ami-0906a869d3cc73525`) &&
    !contains(ImageId, `ami-01f0e91fd944509a6`) &&
    !contains(ImageId, `ami-0b7c25453fb180d70`) &&
    !contains(ImageId, `ami-0f5f96719235bda67`) &&
    !contains(ImageId, `ami-02b2b208ad540bb16`) &&
    !contains(ImageId, `ami-02dcbfda79cc0c3c0`) &&
    !contains(ImageId, `ami-07579ba2e2aa6feba`) &&
    !contains(ImageId, `ami-038d092c486bea95f`) &&
    !contains(ImageId, `ami-07d5aaef17c8f715c`) &&
    !contains(ImageId, `ami-0b96974ad815bfabb`) &&
    !contains(ImageId, `ami-0c09927662c939f41`) &&
    !contains(ImageId, `ami-0f0d8db0584b81dc9`) &&
    !contains(ImageId, `ami-0f126c74e25bf245c`) &&
    !contains(ImageId, `ami-21524b45`) &&
    !contains(ImageId, `ami-80524be4`) &&
    !contains(ImageId, `ami-8ea6b5ea`) &&
    !contains(ImageId, `ami-cfc7d1ab`) &&
    !contains(ImageId, `ami-d4cadab0`) &&
    !contains(ImageId, `ami-d55340b1`) &&
    !contains(ImageId, `ami-061b389db91032dbd`) &&
    !contains(ImageId, `ami-ed100689`) &&
    !contains(ImageId, `ami-0dbea6db447415075`) &&
    !contains(ImageId, `ami-0ff251a24dc8851c5`) &&
    !contains(ImageId, `ami-08aab8d54c1f84eed`) &&
    !contains(ImageId, `ami-093e16ee19accfd1a`) &&
    !contains(ImageId, `ami-0428368d448009e96`) &&
    !contains(ImageId, `ami-0489b79ee2ab95d7d`) &&
    !contains(ImageId, `ami-09471ad3e1f6aee63`) &&
    !contains(ImageId, `ami-07e8834ea6d62f408`) &&
    !contains(ImageId, `ami-00afaad41d7c59cba`) &&
    !contains(ImageId, `ami-0becf4691c4e659db`) &&
    !contains(ImageId, `ami-0258423cb5e98ad12`) &&
    !contains(ImageId, `ami-09abaaa994029622c`) &&
    !contains(ImageId, `ami-0dcf36eecb924fde4`) &&
    !contains(ImageId, `ami-0e4ef195bdb563b9b`) &&
    !contains(ImageId, `ami-07b429c1b48169e43`)
    ].[ImageId]' --output text | \
  sort | uniq > "${AMI_OUTPUT}"
  TOTAL_AMI="$(wc -l ${AMI_OUTPUT} | cut -d' ' -f1)"
  echo "$(dateinfo) Total number of AMI in the region ${REGION}: ${TOTAL_AMI}" >>"${LOG_FILE}"
  #
  # Removing the old AMI Images from the AMI_OUTPUT.
  #
  while IFS= read -r AMI_IMAGE
  do
    echo "$(dateinfo) Deregistering AMI Image: ${AMI_IMAGE}" >>"${LOG_FILE}"
    aws ec2 deregister-image \
       --region "${REGION}" \
       --image-id "${AMI_IMAGE}" >>"${LOG_FILE}"
    ACLI_RC="$?"
    if [[ "$ACLI_RC" -eq 0 ]]; then
      echo "$(dateinfo) Successfully deregistered the AMI Image: ${AMI_IMAGE}" >>"${LOG_FILE}"
    else
      echo "$(dateerror) Unable to deregister the AMI Image: ${AMI_IMAGE}" >>"${LOG_FILE}"
    fi
  done < "${AMI_OUTPUT}"
done
#
# Removing the file and exit.
#
shred -uz "${AMI_OUTPUT}" "${AMI_LOCK_FILE}" >/dev/null 2>&1
exit "${EXIT}"
