#!/usr/bin/env bash
# -*- coding: utf-8 -*-

##
# Managed by: LR Ansible Control Node.
##

##############################################################################
#
# Name        : golang.sh
# Description : Script to setup basic GoLang.
#
##############################################################################

#
# Creating GOPATH
#
if [ ! -d "$HOME"/go ]; then
  mkdir -p "$HOME"/go
fi
#
# Exporting GOPATH
#
export GOPATH="$HOME"/go
export PATH="$PATH":"$GOPATH"/bin
