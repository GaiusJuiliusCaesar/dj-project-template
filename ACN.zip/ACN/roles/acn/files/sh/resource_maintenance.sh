#!/usr/bin/env bash
# -*- coding: utf-8 -*-

##
# Managed by: LR Ansible Control Node.
##

##############################################################################
#
# Name        : resource_maintenance.sh
# Description : Script to get resource usage alert.
# Engineer    : Seshadri Raja | RA
#
##############################################################################

#
# Define Variables
#
DISK_USAGE="$(df / | grep -v 'Filesystem' | awk '{ print $5 }' | sed 's/%//g')"
DISK_ALERT=80
INODE_USAGE="$(df -i / | grep -v 'Filesystem' | awk '{ print $5 }' | sed 's/%//g')"
INODE_ALERT=80
CPU_USAGE="$(top -b -n1 | grep "Cpu(s)" | awk '{ print $2 + $4 }')"
CPU_ALERT=80
MEMORY_USAGE="$(free | \
  awk '/Mem/{ printf("RAM Usage: %.2f%\n"), $3/$2*100 }' | \
  awk '{ print $3 }' | cut -d"." -f1)"
MEMORY_ALERT=80
EMAIL_SUBJECT="Threshold Alert on Ansible Control Node $(hostname -s)"
SMTP_SERVER="smtp=smtp.office365.com:587"
SENDER_ADDRESS="$(aws ssm get-parameters --name \
"/production/classdirect/mail/user" \
--with-decryption \
--output text | \
awk '{ print $6 }')"
SMTP_CREDENTIAL="$(aws ssm get-parameters --name \
"/production/classdirect/mail/pass" \
--with-decryption \
--output text | \
awk '{ print $7 }')"
RECEIVER_ADDRESS="lloydsregister.support@baesystems.com"
CERT_DIR="/etc/pki/nssdb/"
BODY_MESSAGE="Hello,

Please Investigate.

Disk utilization on / partition at: ${DISK_USAGE}
iNODE utilization on / partition at: ${INODE_USAGE}
CPU utilization at: ${CPU_USAGE}
Memory utilization at: ${MEMORY_USAGE}

Thank You."
#
# Check resource usage.
#
if [[ "$DISK_USAGE" -gt "$DISK_ALERT" ]] || \
  [[ "$INODE_USAGE" -gt "$INODE_ALERT" ]] || \
  [[ "$CPU_USAGE" -gt "$CPU_ALERT" ]] || \
  [[ "$MEMORY_USAGE" -gt "$MEMORY_ALERT" ]]; then
  echo "$BODY_MESSAGE" | mailx -S "$SMTP_SERVER" \
    -S smtp-use-starttls \
    -S smtp-auth=login \
    -S smtp-auth-user="$SENDER_ADDRESS" \
    -S smtp-auth-password="$SMTP_CREDENTIAL" \
    -S nss-config-dir="$CERT_DIR" \
    -S ssl-verify=ignore \
    -s "$EMAIL_SUBJECT" \
    -r "$SENDER_ADDRESS" \
    "$RECEIVER_ADDRESS" >/dev/null 2>&1
fi
