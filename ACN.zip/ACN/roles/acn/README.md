Ansible Control Node
=========

This role is used to manage the ansible control node global settings.

Example Playbook
----------------

Add this role in the playbook as following.

    - name: Setup Play
      hosts: servers
      vars_files:
        - "{{ ansible_vault_file_path + 'ACN/acn.vault' }}"
      become: true
      roles:
        - role: "acn"

License
-------

BSD

Author Information
------------------

**LR Platform Team**, [BAE Systems Digital Intelligence](https://baesystems.com/di/)
