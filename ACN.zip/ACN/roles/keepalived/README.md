Keepalived
=========

This role is used to manage Keepalived LB.

Example Playbook
----------------

Add this role in the playbook as following.

    - name: Setup Play
      hosts: servers
      vars_files:
        - "{{ ansible_vault_file_path }}ED/keepalived_lb.vault"
      roles:
        - role: keepalived

License
-------

BSD

Author Information
------------------

**Engineering Support**, [BAE Systems Applied
Intelligence](https://baesystems.com/ai/)
