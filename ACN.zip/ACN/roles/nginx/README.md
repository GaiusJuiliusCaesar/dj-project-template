Nginx
=========

This role is used to manage Nginx service.

Example Playbook
----------------

Add this role in the playbook as following.

    - name: Setup Play
      hosts: servers
      roles:
        - role: nginx

License
-------

BSD

Author Information
------------------

**Engineering Support**, [BAE Systems Applied
Intelligence](https://baesystems.com/ai/)
